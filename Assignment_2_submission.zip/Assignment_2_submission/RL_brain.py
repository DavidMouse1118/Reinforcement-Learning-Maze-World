
import numpy as np
import pandas as pd


class rlalgorithm:
    def __init__(self, actions, ...):
        self.actions = actions  

    def choose_action(self, observation):
	# implement this. 
        return action

    def learn(...):
	#implement this. Learn something from the transition

